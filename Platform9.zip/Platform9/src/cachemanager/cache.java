package cachemanager;

import java.awt.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Queue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


/*This file implements read-write locks. readacquire() and readrelease() are methods 
 * for acquiring and release locks while reading data. Writeacuqire() and writerelease are methods for
 * writing data. Readacquire can acquire lock for read if there are no writing threads in
 * the critical section (CS), though it can acquire a lock if there are multiple reader threads in CS.
 * Writeacquire() method can acquire a lock only when there in no reader thread or writer thread in the CS.
 * Readerrelease() method release the read lock and decrement the reader thread counter and then wake:
 * 1. One writer thread first (if there is any)
 * 2. Then wakes all the reader threads (if there is any)
 * Writerelease release the write lock and decrement the writer count which can be either 0 or 1 only. 
 * It then wake:
 * 1. All the reader threads waiting  to acquire lock(if any exist)
 * 2. wake one writer thread  waiting  to acquire lock (if there is any)
 * 
 * */


public class cache extends Thread{
	private String name;
	int readcount;  //number of reader threads in CS
	int writecount; //number of writer threds in CS
	int writewait; //number of writer thread waiting to acquire CS
	ReentrantLock lock; 
	Queue readlist;  //list of waiting reader threads
	Queue writelist; //list of waiting writer threads
//	ArrayList readerthreads;
	
	public cache(final String name){
		try{
			this.lock =new ReentrantLock();
			this.name = name;
			readcount =0;
			writecount = 0;
			writewait= 0;
			readlist = new LinkedList<Thread>();
			writelist = new LinkedList<Thread>();
			    
		}
		catch(Exception e){
			System.out.println("Exception encountered: "+e);
		}
		
	}
	
	public void readacquire(ReentrantLock lock){
		try{
//			Thread curthread = currentThread();	
			/*
			 * checks whether current thread already hold the lock
			 * 
			 * */
			
			if(this.holdsLock(lock)){
				System.out.println("lock already acquired");
				throw new Exception();
			}	
			
			lock.lock();	
			
			/*
			 * if there is a writer thread in CS then wait
			 * 
			 * */
			if(writecount>0){
				readlist.add(this);
				lock.unlock();
				this.wait();
			}	
			else{
				/*
				 * increment the counter after acquiring CS
				 * 
				 * */
				
			readcount++;
			//curthread.status =1;
			lock.unlock();
			}
		}
		catch(Exception e){
			System.out.println("Exception encountered1: "+e);
		}	
	}
	
	public void readrelease(Lock ob){
	try{
		lock.lock();
		
		/*
		 * check if there are any locks acquired
		 * */
		if(readcount<1){
			System.out.println("No locks are acquired");
			throw new Exception();
		}
		System.out.println(readcount);
		readcount--;
		
		//readerthreads.add(curthread);
		
		/*
		 * wake a writer thread first so as to avoid reading stale data
		 * */
		if(writewait==1){
			Thread t = (Thread)writelist.poll();
			t.notify();
		}
		
		/*I'm not using notifyall() method since it can wake up all the waiting threads
		 * including both readers or writers. But I want to wake up only reader threads.
		 * Another way is to write a CV and create different classes for the reader and 
		 * the writer threads and wake them separately upon release of a lock.But since 
		 * this approach will going to take more time therefore I'm following my current 
		 * approach.
		 * */
		while(!readlist.isEmpty()){
			Thread t = (Thread)readlist.poll();
			t.notify();
		}
		lock.unlock();
		
	}
	catch(Exception e){
		System.out.println("Error while readlock release: "+e);
	}
		
	}
	
	public void writeacquire(Lock lock){
		try{
//			Thread curthread = currentThread();
			if(this.holdsLock(lock)){
				System.out.println("Write lock already acquired by this thread");
				throw new Exception();
			}
			
			lock.lock();
			if(readcount>0 || writecount>0){
				writewait=1;
				writelist.add(this);
				lock.unlock();
				this.wait();
		
			}
			else{
			writecount = 1 ;
			writewait =1;
			//set status of all previous reader threads as stale
//			ListIterator it = readerthreads.listIterator();
//			while(it.hasNext()){
//				Mythread t = (Mythread)it.next();
//				t.status = 0;	
//			}
			lock.unlock();	
			}
		}
		catch(Exception e){
			System.out.println("Exception encountered2: "+e);
		}
	}
	
	public void writerelease(Lock lock){
		try{
			
			
			if(writecount!=1 || writewait!=1){
				System.out.println("Writecount or writewait has incorrect values"+writecount+":"+writewait);
				System.out.println("Invalid lock release");
				throw new Exception();
			}
			lock.lock();
			System.out.println(writecount);
			writecount = 0;
			writewait = 0;
			while(!readlist.isEmpty()){
				Thread t = (Thread)readlist.poll();
				t.notify();
			}
			if(!writelist.isEmpty()){
				Thread t = (Thread)writelist.poll();
				t.notify();
			}
			lock.unlock();
			
		}
		catch(Exception e){
			System.out.println("Exception excountered3: "+e);
		}
	}
	
	public static void main(String[] ar){
		cache ob = new cache("lock1");
		cache ob1 = new cache("lock2");
		
		ob.readacquire(ob.lock);
		ob1.writeacquire(ob1.lock);
		ob.readrelease(ob.lock);
		ob1.writerelease(ob1.lock);
		
	}
}


